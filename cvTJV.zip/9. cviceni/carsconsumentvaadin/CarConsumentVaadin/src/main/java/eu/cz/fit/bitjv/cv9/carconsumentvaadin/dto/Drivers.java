/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eu.cz.fit.bitjv.cv9.carconsumentvaadin.dto;

import java.util.List;

/**
 *
 * @author jpavlicek
 */
public class Drivers {
    List<Driver> driver;

    public List<Driver> getDriver() {
        return driver;
    }

    public void setDriver(List<Driver> driver) {
        this.driver = driver;
    }

 
}
