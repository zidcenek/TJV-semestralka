/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eu.cz.fit.bitjv.cv9.carconsumentvaadin.dto;

import java.util.List;

/**
 *
 * @author jpavlicek
 */
public class Cars {

    public List<Car> getCar() {
        return car;
    }

    public void setCar(List<Car> car) {
        this.car = car;
    }
    private List<Car> car;
    
    
}
