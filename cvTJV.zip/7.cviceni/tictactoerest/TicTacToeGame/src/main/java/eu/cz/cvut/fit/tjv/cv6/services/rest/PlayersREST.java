package eu.cz.cvut.fit.tjv.cv6.services.rest;

import eu.cz.cvut.fit.tjv.cv6.tictactoe_cli.player.Player;
import eu.cz.cvut.fit.tjv.cv6.tictactoe_cli.player.Players;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

/**
 * REST service for CRUD of Player.
 *
 * @author aubrech
 */
@Stateless
@Path("/player")
public class PlayersREST {

    public PlayersREST() {
    }

    @POST // nebo @GET
    //@Path("{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Player create(String name) {
        Player player = new Player(name);
        return player;
    }
    
    @GET
    @Path("/count")
    @Produces(MediaType.APPLICATION_JSON)
    public int count() {
        return 2;
    }
    
    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Player getPlayer(@PathParam("id") int id){
        List<Player> players = new ArrayList();
        players.add(new Player("Josef"));
        players.add(new Player("Charlie"));
        return players.get(id);
    }
    
    @GET
    @Path("/players")
    @Produces(MediaType.APPLICATION_JSON)
    public Players getPlayers(){
      Players ps = new Players();
      ps.add(new Player("Joasef"));
      ps.add(new Player("Charlie"));
      return ps;
    }
    
    
    // naimplementujte create, list, ziskani jednoho hrace, count
}
