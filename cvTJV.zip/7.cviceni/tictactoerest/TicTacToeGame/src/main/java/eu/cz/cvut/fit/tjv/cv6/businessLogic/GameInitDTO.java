/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eu.cz.cvut.fit.tjv.cv6.businessLogic;

/**
 *
 * @author pavlijo5
 */
public class GameInitDTO {
      private String gridSize;
      private String gameNtoWin;
      private String player1;
      private String player2;

    public String getGridSize() {
        return gridSize;
    }

    public void setGridSize(String gridSize) {
        this.gridSize = gridSize;
    }

    public String getGameNtoWin() {
        return gameNtoWin;
    }

    public void setGameNtoWin(String gameNtoWin) {
        this.gameNtoWin = gameNtoWin;
    }

    public String getPlayer1() {
        return player1;
    }

    public void setPlayer1(String player1) {
        this.player1 = player1;
    }

    public String getPlayer2() {
        return player2;
    }

    public void setPlayer2(String player2) {
        this.player2 = player2;
    }
  
      
      
}
