/*
 * (c) FIT CVUT
 */
package eu.cz.cvut.fit.tjv.cv6.tictactoe_cli.game;

/**
 * Indicates attempt to mark board's place that is already marked.
 * @author guthondr
 */
public class IllegalTurnException extends RuntimeException {
    
}
